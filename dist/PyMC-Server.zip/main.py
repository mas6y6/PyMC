import sys
import os
import zipfile
from tkinter.messagebox import *
from subprocess import *
import json
import webbrowser
print("Checking for assets...")
startdirectory = os.getcwd()
app_directory = None
home_directory = os.path.expanduser('~')

#https://github.com/mas6y6/PyMC-ServerASSETS/raw/main/Assets.zip

def _setupdirectory(exists=False):
    global app_directory, home_directory
    print("Downloading assets")
    run("pip install requests",shell=True)
    import requests
    url = "https://github.com/mas6y6/PyMC-ServerASSETS/raw/main/Assets.zip"
    
    os.chdir(home_directory)
    if exists == False:
        os.mkdir("PyMC-Server")
    os.chdir("PyMC-Server")

    # Make a request to the GitHub API
    response = requests.get(url)

    # Check if the request was successful
    if response.status_code == 200:
        with open("assets.zip", "wb") as f:
            f.write(response.content)
            f.close()
    else:
        showerror("PyMC-Server","An error occurred while downloading assets")
    
    print("Done")
    print("Unziping data...")
    with zipfile.ZipFile('assets.zip', 'r') as zip_ref:
        zip_ref.extractall('.')
    print("Done")
    print("Finishing up...")
    app_directory = os.getcwd()
    try:
        with open("settings.json","w") as f:
            json.dump({"servers":[]},f,indent=4)
    except Exception as e:
        print(e)
        showerror("PyMC-Server",f"An error occurred {e}")
        exit()
    print("Done")

#Check for app assets if installed

os.chdir(home_directory)
if os.path.exists("PyMC-Server"):
    os.chdir(home_directory)
    os.chdir("PyMC-Server")
    if not os.listdir():
        _setupdirectory(exists=True)
    else:
        app_directory = os.getcwd()
        
    if os.path.exists("Assets"):
        print("Assets found")
    else:
        print("Assets broken redownloading it")
else:
    _setupdirectory()

#Starting app

print("Founded app directory " + app_directory)

print("Starting app...")

sys.path.insert(1, f'{app_directory}/Assets')

from tkinter.messagebox import *
from tkinter.filedialog import *
from tkinter.dialog import *
import tkinter as tk
import tkinter.font as Font
import json
import requests
import urllib.request
from threading import Thread
import time
import editer 
import windows
from PIL import Image, ImageTk
import ttkbootstrap as ttk
from playsound import playsound
#import packages

root = tk.Tk()
root.title("PyMC-Server")
root.geometry("500x300")
root.resizable(False,False)

menubar = tk.Menu(root)

filemenu = tk.Menu(menubar)

def restartapp():
    global startdirectory
    showinfo("PyMC-Server","This app will close to save changes")
    exit()

def appsettings():
    global mainframe
    root.title(f"PyMC-Server - App settings")
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="App settings",font=("",30))
    l1.grid(row=0,column=0)
    b1 = ttk.Button(master=mainframe,text="Close",command=restartapp)
    b1.grid(row=0,column=1,padx=5)
    b1 = ttk.Button(master=mainframe,text="Check for updates",command=checkforupdates)
    b1.grid(row=1,column=1,padx=5)
    mainframe.pack()

filemenu.add_command(label="About",command=windows.showabout)
filemenu.add_command(label="Open app Settings",command=appsettings)
filemenu.add_command(label="Stop server")
filemenu.add_command(label="Start server")
filemenu.add_command(label="Return to startmenu")
filemenu.add_separator()
filemenu.add_command(label="Quit",command=root.quit)

menubar.add_cascade(label="Server", menu=filemenu)

root.config(menu=menubar)

appversion = "v1.5"
server_directory = None
server_runtime = None
progressbar = None
run_server_dir = None
server_settings = None
Done = None
settings = None
mainframe = None
newserver = {}
server_running = False
start_button = None
stop_button = None
global_mc_settings = {}
global_varables = {}

def download(url,tofile):
    urllib.request.urlretrieve(url,tofile,showloading)
    urllib.request.urlcleanup()

def checkforupdates():
    print("Checking for updates...")
    try:
        data = requests.get("https://api.github.com/repos/mas6y6/PyMC-Server/tags")
        datade = json.loads(data.text)
        new = datade[0]["name"]
        if not new == appversion:
            print("Update found version:")
            print(f"{appversion} >>> {new}")
            q = askquestion("PyMC-Server","An newer version of PyMC-Server was found\nDo you want to install it?")
            if q == "yes":
                webbrowser.open(f'https://github.com/mas6y6/PyMC-Server/releases/tag/{new}')
            
        else:
            print("No updates found using latest version:")
            print(f"{appversion} === {new}")
            showinfo("PyMC-Server","You are running the latest version\nNo new updates found")
            return False
    except Exception as e:
        showerror("PyMC-Server",f"An error occured when trying to install update {e}")
        return e

def reset_global_varables():
    global global_varables
    global_varables = {}

def latestgetappversion():
    data = get("https://api.github.com/repos/mas6y6/PyMC-Server/tags")
    tags = json.loads(data.text)
    return tags[0]["name"]

def latestgetassetsversion():
    data = get("https://api.github.com/repos/mas6y6/PyMC-ServerASSETS/tags")
    tags = json.loads(data.text)
    return tags[0]["name"]

def open_settings():
    global settings
    with open(f"{home_directory}/PyMC-Server/settings.json","r") as f:
        settings = json.load(f)
        f.close()

def update_settings():
    global settings
    with open(f"{home_directory}/PyMC-Server/settings.json","w") as f:
        json.dump(settings,f,indent=4)
        f.close()

open_settings()

def check_if_server_is_none(*n):
    global global_varables
    if global_varables['item_selected'].get() == 'None':
        global_varables['b2'].config(state="disabled")
    else:
        global_varables['b2'].config(state="enabled")

def startmenu(re=False):
    root.title("PyMC-Server - Startmenu")
    global mainframe, global_varables
    if re == False:
        mainframe = None
    else:
        mainframe.destroy()

    mainframe = ttk.Frame(master=root)

    global_varables['item_selected'] = tk.StringVar()
    global_varables['item_selected'].set("None")

    l1 = ttk.Label(master=mainframe,text="Welcome to PyMC-Server",font=("",20))
    l1.pack(pady=40)

    global_varables['b2'] = ttk.Button(master=mainframe,text="Open server",command=lambda: open_server(global_varables['item_selected'].get()))
    global_varables['b2'].pack(side="left")

    b1 = ttk.Button(master=mainframe,text="Add server",command=add_server1)
    b1.pack(side="left",padx=10)

    s = []
    for i in range(len(settings['servers'])):
        f = i - 1
        s.append(settings['servers'][f]['name'])
    
    print(s)
    s.insert(0,"None")

    check_if_server_is_none()

    menu = ttk.OptionMenu(mainframe,global_varables["item_selected"],*s,command=check_if_server_is_none)
    menu.pack()

    mainframe.pack()

def open_server(value):
    print(value)
    global server_directory, global_varables
    found = False
    for i in range(len(settings['servers'])):
        s = i
        if settings["servers"][s]['name'] == value:
            found = True
            break

    if value == 'None':
        showerror("PyMC-Server","That is an invalid server")
    elif found == True:
        global_varables['server_index'] = s
        server_directory = settings["servers"][global_varables['server_index']]['directory']
        main_menu()
    else:
        pass

def on_closing():
    global server_running
    if server_running == True:
        send_stop()
    else:
        root.quit()

def add_server1():
    global mainframe, newsettings
    root.title("PyMC-Server - New server")
    newsettings = {}
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="Whats the name of this new server?",font=("",20))
    l1.pack()
    e1 = ttk.Entry(master=mainframe)
    e1.pack(side="left")
    e1.insert(0,"New Server")
    b1 = ttk.Button(master=mainframe,text="Next",command=lambda:add_server2(e1.get()))
    b1.pack(side="left",padx=10)
    
    mainframe.pack()

def add_server2(val):
    global newserver
    if val == "":
        showerror("PyMC-Server","Please put a name for your server")
        return
    newserver["name"] = val
    global mainframe
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="Gamemode?",font=("",20))
    l1.pack()

    group = tk.StringVar()
    group.set("None")

    radio1 = ttk.Radiobutton(master=mainframe, text="Survival", value="survival", variable=group)
    radio2 = ttk.Radiobutton(master=mainframe, text="Creative", value="creative", variable=group)
    radio1.pack(side="left",padx=4)
    radio2.pack(side="left")
    b1 = ttk.Button(master=mainframe,text="Next",command=lambda:add_server3(group.get()))
    b1.pack(side="left",padx=10)
    mainframe.pack()

def add_server3(val):
    global newserver
    if val == "None":
        showerror("PyMC-Server","Please select a option")
        return
    newserver["gamemode"] = val
    global mainframe
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="Difficulty?",font=("",20))
    l1.pack()

    group = tk.StringVar()
    group.set("None")

    radio1 = ttk.Radiobutton(master=mainframe, text="Normal", value="normal", variable=group)
    radio2 = ttk.Radiobutton(master=mainframe, text="Easy", value="easy", variable=group)
    radio3 = ttk.Radiobutton(master=mainframe, text="Hard", value="hard", variable=group)
    radio4 = ttk.Radiobutton(master=mainframe, text="Peaceful", value="peaceful", variable=group)
    radio1.pack()
    radio2.pack()
    radio3.pack()
    radio4.pack()

    b1 = ttk.Button(master=mainframe,text="Next",command=lambda:add_server4(group.get()))
    b1.pack(pady=10)
    mainframe.pack()

def _change_directory(val,l2):
    val.set(askdirectory())
    print(val.get())
    l2.config(text=val.get())

def add_server4(val):
    global newserver
    if val == "None":
        showerror("PyMC-Server","Please select a difficulty")
        return
    newserver["difficulty"] = val
    global mainframe
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="Where do you want to place your server?",font=("",20))
    l1.pack()

    dir = tk.StringVar()
    dir.set("None")

    l2 = ttk.Label(master=mainframe,text=dir.get())
    l2.pack()

    b1 = ttk.Button(master=mainframe,text="Change directory",command=lambda:_change_directory(dir,l2))
    b1.pack()

    b2 = ttk.Button(master=mainframe,text="Next",command=lambda: add_server5(dir.get()))
    b2.pack(pady=4)
    mainframe.pack()            

def add_server5(val):
    global newserver
    if val == "None" or val=="" or val==None:
        showerror("PyMC-Server","Please select a directory")
        return
    
    try:
        re = json.loads(requests.get("https://api.papermc.io/v2/projects/paper",timeout=10).text)
    except Exception as e:
        showerror('PyMC-Server',f"An error occurred while communicating to PaperMC {e}")
        return

    newserver["dir"] = val
    global mainframe
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="What version do you want",font=("",20))
    l1.pack()

    ver = tk.StringVar()
    ver.set("None")
    print(ver.get())

    re["versions"].insert(0,"None")
    m1 = re["versions"][len(re["versions"]) - 1] + " Latest version"
    re["versions"].insert(1,m1)

    vers = ttk.OptionMenu(mainframe,ver,*re["versions"])
    vers.pack()

    b2 = ttk.Button(master=mainframe,text="Next",command=lambda: add_server6(ver.get(),re["versions"][len(re["versions"]) - 1]))
    b2.pack(pady=4)
    mainframe.pack()

def add_server6(val,val2):
    global newserver
    if val == "None":
        showerror("PyMC-Server","Please select a version")
        return
    
    if val.find("Latest version") == -1:
        newserver["version"] = val
        ver = val
    else:
        newserver["version"] = val2
        ver = val2
    try:
        re = json.loads(requests.get(f"https://api.papermc.io/v2/projects/paper/versions/{ver}",timeout=10).text)
    except Exception as e:
        showerror('PyMC-Server',f"An error occurred while communicating to PaperMC {e}")
        return

    global mainframe
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="What build do you want",font=("",20))
    l1.pack()

    build = tk.StringVar()
    build.set("None")

    re["builds"].insert(0,"None")
    m1 = str(re["builds"][len(re["builds"]) - 1]) + " Latest build"
    re["builds"].insert(1,m1)

    builds = ttk.OptionMenu(mainframe,build,*re["builds"])
    builds.pack()

    b2 = ttk.Button(master=mainframe,text="Next",command=lambda: add_server7(build.get(),str(re["builds"][len(re["builds"]) - 1])))
    b2.pack(pady=4)
    mainframe.pack()

def add_server7(val,val2):
    global newserver

    print(newserver)

    if val == "None":
        showerror("PyMC-Server","Please select a build")
        return
    
    if val.find("Latest build") == -1:
        newserver["build"] = val
    else:
        newserver["build"] = val2

    global mainframe
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)

    print()
    l1 = ttk.Label(master=mainframe,text="Check",font=("",20))
    l1.pack()

    l2 = ttk.Label(master=mainframe,text="Name: " + newserver["name"],font=("",15))
    l2.pack()

    l3 = ttk.Label(master=mainframe,text="Difficulty: " + newserver["difficulty"],font=("",15))
    l3.pack()

    l4 = ttk.Label(master=mainframe,text="Gamemode: " + newserver["gamemode"],font=("",15))
    l4.pack()

    l4 = ttk.Label(master=mainframe,text="Version: " + newserver["version"],font=("",15))
    l4.pack()

    l5 = ttk.Label(master=mainframe,text="Build: " + newserver["build"],font=("",15))
    l5.pack()

    l6 = ttk.Label(master=mainframe,text="Directory: " + newserver["dir"],font=("",15))
    l6.pack()

    l7 = ttk.Label(master=mainframe,text='If this is correct then click "Install" if not then click "Restart"',font=("",12))
    l7.pack()

    b1 = ttk.Button(master=mainframe,text="Install",command=lambda: _goto(1))
    b1.pack(side="left",pady=9)

    b2 = ttk.Button(master=mainframe,text="Restart",command=lambda: _goto(2))
    b2.pack(side="left",pady=9,padx=3)

    b2 = ttk.Button(master=mainframe,text="Go to start up page",command=lambda: _goto(3))
    b2.pack(side="left",pady=9,padx=3)
    mainframe.pack()
    

def start():
    global server_running, start_button,stop_button, global_varables
    server_running = True
    start_button.config(state="disabled")
    stop_button.config(state="enabled")
    playsound(f"{app_directory}/Assets/notification.mp3")
    global_varables["thread_server_runtime"] = Thread(target=run_server)
    global_varables["thread_server_runtime"].start()

def send_stop():
    global server_running, stop_button, start_button, global_varables, server_runtime
    server_runtime.stdin.write(b'stop\n')
    server_runtime.stdin.close()

def run_server(stdin=PIPE):
    global Done, server_running, start_button, global_varables, run_server_dir, server_runtime
    Done = True
    try:
        usepopen = global_varables['runtime_options']["usepopen"]
    except:
        usepopen = False

    if usepopen == False:
        run("sh start.sh",cwd=run_server_dir,shell=True)
        server_runtime = False
    elif usepopen == True:
        server_runtime = Popen("sh start.sh",cwd=run_server_dir,shell=True,stdin=stdin)
        server_runtime.wait()
    else:
        raise TypeError()

    try:
        global_varables["running_window"].join()
    except:
        pass

    try:
        start_button.config(state="enabled")
        stop_button.config(state="disabled")
    except:
        pass

    Done = False
    server_running = False

def install():
    global mainframe, newserver, progressbar
    mainframe = ttk.Frame()
    l1 = ttk.Label(master=mainframe,text="Installing",font=("",20))
    l1.pack()
    l2 = ttk.Label(master=mainframe,text="Downloading server...",font=("",15))
    l2.pack(pady=15)
    progressbar = ttk.Progressbar(master=mainframe,length=450,bootstyle="striped",mode="determinate")
    progressbar.pack(pady=20)
    b1 = ttk.Button(master=mainframe,text="Next",command=install2,state="disabled")
    b1.pack(pady=35)
    mainframe.pack()
    dir = newserver["dir"]
    ver = newserver["version"]
    build = newserver["build"]
    download(f"https://api.papermc.io/v2/projects/paper/versions/{ver}/builds/{build}/downloads/paper-{ver}-{build}.jar",f"{dir}/paper.jar")
    print("Downloaded")
    l2.config(text="Complete")
    b1.config(state="enabled")

def install2():
    global mainframe, newserver, progressbar
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="Ram value",font=("",20))
    l1.pack()
    e1 = ttk.Entry(master=mainframe)
    e1.pack()
    e1.insert(0,"1024M")
    b1 = ttk.Button(master=mainframe,text="Next",command=lambda: install3(e1.get()))
    b1.pack(pady=4)
    mainframe.pack()


def install3(value):
    global mainframe, newserver, progressbar
    if value == "":
        showerror("Please put a ram number")
        return
    newserver["mem"] = value

    mainframe.destroy()
    mainframe = ttk.Frame()
    l1 = ttk.Label(master=mainframe,text="Unpacking",font=("",20))
    l1.pack()
    l2 = ttk.Label(master=mainframe,text="Creating Startup File...",font=("",15))
    l2.pack(pady=15)
    progressbar = ttk.Progressbar(master=mainframe,length=450,bootstyle="primary",mode="indeterminate")
    progressbar.pack(pady=20)
    b1 = ttk.Button(master=mainframe,text="Next",command=install4,state="disabled")
    b1.pack()
    mainframe.pack()
    progressbar.start()
    dir = newserver["dir"]
    mem = newserver["mem"]
    os.chdir(dir)
    with open("start.sh","w") as f:
        f.write(f"java -Xmx{mem} -Xms{mem} -jar paper.jar ")
        f.close()
    l2.config(text="Unpacking server...")
    Thread(target=lambda: run_server()).start()
    time.sleep(0.1)
    while Done:
        mainframe.update()
    progressbar.stop()
    progressbar["value"] = 0
    b1.config(state="enabled")
    l2.config(text="Done")

def install4():
    global mainframe, newserver
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="Accept the EULA",font=("",20))
    l1.pack()
    q = tk.StringVar()
    q.set("None")
    l2 = ttk.Label(master=mainframe,text="To continue use need to accept the eula")
    l2.pack()
    e1 = ttk.Entry(master=mainframe)
    e1.pack()
    e1.insert(0,"https://www.minecraft.net/en-us/eula")
    e1.config(state="readonly")
    r1 = ttk.Radiobutton(master=mainframe,text="Accept",value="true",variable=q)
    r2 = ttk.Radiobutton(master=mainframe,text="Don't accept",value="false",variable=q)
    r1.pack()
    r2.pack()
    b1 = ttk.Button(master=mainframe,text="Next",command=lambda: install5(q.get()))
    b1.pack(pady=4)
    mainframe.pack()

def install5(var):
    global mainframe, run_server_dir, newserver, server_directory
    mainframe.destroy()
    server_directory = newserver["dir"]
    mainframe = ttk.Frame(master=root)
    l1 = ttk.Label(master=mainframe,text="Success",font=("",20))
    l1.pack()
    l2 = ttk.Label(master=mainframe,text="Your server is now ready to run",font=("",15))
    l2.pack(pady=15)
    b1 = ttk.Button(master=mainframe,text="Open server manager",command=lambda: open_server(newserver['name']))
    b1.pack()
    b2 = ttk.Button(master=mainframe,text="Go to start menu",command=lambda: _goto(3))
    b2.pack()
    mainframe.pack()
    if var == "None":
        showerror("PyMC-Server","Please select a option")
        return None
    else:
        if var == "true":
            with open(f"{newserver['dir']}/eula.txt","r+") as f:
                lines = f.readlines()
                lines[2] = f"eula={var}"
                f.seek(0)
                f.writelines(lines)
                f.truncate()
                f.close()
        else:
            showerror("PyMC-Server","you need to except the EULA continue")
            return None
    f = open(f"{newserver['dir']}/input.txt","w")
    f.close()
    e = editer.server(os.getcwd())
    e.gamemode(newserver["gamemode"])
    e.difficulty(newserver["difficulty"])
    e.close()
    dir = newserver["dir"]
    f = open(f"{dir}/plugins/plugins.json","w")
    json.dump({'Plugins':[]},f)
    f.close()
    settings["servers"].append({"name":newserver["name"],"directory":newserver["dir"],"mem":newserver["mem"],"build":newserver["build"],"version":newserver["version"]})
    update_settings()

def _goto(page):
    global mainframe
    mainframe.destroy()
    if page == 1:
        install()
    elif page == 2:
        add_server1()
    elif page == 3:
        startmenu()
    else:
        pass

def showloading(count,downloaded,size):
    global progressbar, mainframe
    if count == 0:
        progressbar.config(maximum=size)
    else:
        progressbar.step(downloaded)
    mainframe.update()

def updateserversettings():
    e = editer.server(server_directory)
    try:
        print(global_mc_settings["gamemode"].get())
        gamemode = global_mc_settings["gamemode"].get()
        print(global_mc_settings["difficulty"].get())
        diff = global_mc_settings["difficulty"].get()
        print(global_mc_settings["hardcore"].get())
        hardcore = global_mc_settings["hardcore"].get()
        print(global_mc_settings["seed"].get())
        seed = global_mc_settings["seed"].get()
        if gamemode == 2:
            e.gamemode("creative")
        else:
            e.gamemode("survival")
        
        if diff == 2:
            e.difficulty('normal')
        elif diff == 1:
            e.difficulty('easy')
        elif diff == 3:
            e.difficulty('hard')
        else:
            e.difficulty('peaceful')
        
        e.hardcore(hardcore)
        e.seed(seed)
    except:
        pass
    e.close()

def saveandgohome():
    updateserversettings()
    main_menu()

def openserversettings():
    root.geometry("700x400")
    global mainframe, global_mc_settings, server_directory, global_varables
    server = settings['servers'][global_varables["server_index"]]
    t = server["name"]
    root.title(f"PyMC-Server - {t} - Settings")
    mainframe.destroy()
    mainframe = ttk.Frame(master=root)
    e = editer.server(server_directory)
    b1 = ttk.Button(master=mainframe,text="Back",command=saveandgohome)
    b1.grid(row=0,column=0)
    b1 = ttk.Button(master=mainframe,text="Apply",command=updateserversettings)
    b1.grid(row=0,column=1)

    print(e.get(18))
    print(e.get(7))
    print(e.get(21))
    print(e.get(26))

    var1 = e.get(18)
    var2 = e.get(7)
    var3 = e.get(21)
    var4 = e.get(26)

    if var1 == 'survival':
        global_mc_settings["gamemode"] = tk.IntVar(mainframe,1)
    else:
        global_mc_settings["gamemode"] = tk.IntVar(mainframe,2)
    
    if var2 == 'easy':
        global_mc_settings["difficulty"] = tk.IntVar(mainframe,1)
    elif var2 == 'normal':
        global_mc_settings["difficulty"] = tk.IntVar(mainframe,2)
    elif var2 == 'hard':
        global_mc_settings["difficulty"] = tk.IntVar(mainframe,3)
    else:
        global_mc_settings["difficulty"] = tk.IntVar(mainframe,4)
    
    if var3 == 'false':
        global_mc_settings["hardcore"] = tk.BooleanVar(mainframe,False)
    else:
        global_mc_settings["hardcore"] = tk.BooleanVar(mainframe,True)
    
    global_mc_settings["seed"] = tk.StringVar(mainframe,var4)

    g1 = ttk.Label(master=mainframe,text="Gamemode")
    g1.grid(row=1,column=0)
    gr11 = ttk.Radiobutton(master=mainframe,text="Survival",value=1,variable=global_mc_settings["gamemode"])
    gr11.grid(row=1,column=1,pady=1)
    gr21 = ttk.Radiobutton(master=mainframe,text="Creative",value=2,variable=global_mc_settings["gamemode"])
    gr21.grid(row=1,column=2,padx=1,pady=3)

    g2 = ttk.Label(master=mainframe,text="Difficulty")
    g2.grid(row=2,column=0)
    gr12 = ttk.Radiobutton(master=mainframe,text="Normal",value=2,variable=global_mc_settings["difficulty"])
    gr12.grid(row=2,column=1)
    gr22 = ttk.Radiobutton(master=mainframe,text="Easy",value=1,variable=global_mc_settings["difficulty"])
    gr22.grid(row=2,column=2,padx=1)
    gr32 = ttk.Radiobutton(master=mainframe,text="Hard",value=3,variable=global_mc_settings["difficulty"])
    gr32.grid(row=2,column=3,padx=1)
    gr42 = ttk.Radiobutton(master=mainframe,text="Peaceful",value=4,variable=global_mc_settings["difficulty"])
    gr42.grid(row=2,column=4,padx=1)

    g3 = ttk.Label(master=mainframe,text="Hardcore")
    g3.grid(row=3,column=0)
    gr13 = ttk.Radiobutton(master=mainframe,text="On",value=True,variable=global_mc_settings["hardcore"])
    gr13.grid(row=3,column=1)
    gr23 = ttk.Radiobutton(master=mainframe,text="Off",value=False,variable=global_mc_settings["hardcore"])
    gr23.grid(row=3,column=2,padx=1)

    g4 = ttk.Label(master=mainframe,text="Seed")
    g4.grid(row=4,column=0)
    ge41 = ttk.Entry(master=mainframe,textvariable=global_mc_settings['seed'])
    ge41.grid(row=4,column=1)

    b3 = ttk.Button(master=mainframe,text="Open startup settings",command=openserverstartsettings)
    b3.grid(row=0,column=3)

    e.close()
    mainframe.pack()

def gotosettingsmenu():
    update_settings()
    openserversettings()

def openserverstartsettings():
    global mainframe, global_mc_settings, server_directory, global_varables
    server = settings['servers'][global_varables["server_index"]]
    t = server["name"]
    root.title(f"PyMC-Server - {t} - Startup Settings")
    mainframe.destroy()
    e = editer.server(server_directory)
    mainframe = ttk.Frame(master=root)
    b1 = ttk.Button(master=mainframe,text="Back",command=gotosettingsmenu)
    b1.grid(row=0,column=0)
    l1 = ttk.Label(master=mainframe,text="Work in progress")
    l1.grid(row=1,column=0)
    mainframe.pack()
    e.close()
    mainframe.pack()

def plugins():
    global mainframe, global_mc_settings, server_directory, global_varables
    server = settings['servers'][global_varables["server_index"]]
    t = server["name"]
    root.title(f"PyMC-Server - {t} - Plugin manager")
    mainframe.destroy()
    e = editer.server(server_directory)
    mainframe = ttk.Frame(master=root)
    b1 = ttk.Button(master=mainframe,text="Back",command=main_menu)
    b1.grid(row=0,column=0)
    l1 = ttk.Label(master=mainframe,text="Work in progress")
    l1.grid(row=1,column=0)
    mainframe.pack()
    e.close()
    mainframe.pack()

def plugins():
    global mainframe, global_mc_settings, server_directory, global_varables
    server = settings['servers'][global_varables["server_index"]]
    t = server["name"]
    root.title(f"PyMC-Server - {t} - Plugin manager")
    mainframe.destroy()
    e = editer.server(server_directory)
    mainframe = ttk.Frame(master=root)
    b1 = ttk.Button(master=mainframe,text="Back",command=main_menu)
    b1.grid(row=0,column=0)
    l1 = ttk.Label(master=mainframe,text="Work in progress")
    l1.grid(row=1,column=0)
    mainframe.pack()
    e.close()
    mainframe.pack()

def worldmanager():
    global mainframe, global_mc_settings, server_directory, global_varables
    server = settings['servers'][global_varables["server_index"]]
    t = server["name"]
    root.title(f"PyMC-Server - {t} - World manager")
    mainframe.destroy()
    e = editer.server(server_directory)
    mainframe = ttk.Frame(master=root)
    b1 = ttk.Button(master=mainframe,text="Back",command=main_menu)
    b1.grid(row=0,column=0)
    l1 = ttk.Label(master=mainframe,text="Work in progress")
    l1.grid(row=1,column=0)
    mainframe.pack()
    e.close()
    mainframe.pack()

def serverlogging():
    global mainframe, global_mc_settings, server_directory, global_varables
    server = settings['servers'][global_varables["server_index"]]
    t = server["name"]
    root.geometry("600x400")
    root.title(f"PyMC-Server - {t} - Logs")
    mainframe.destroy()
    e = editer.server(server_directory)
    mainframe = ttk.Frame(master=root)
    b1 = ttk.Button(master=mainframe,text="Back",command=main_menu)
    b1.grid(row=0,column=0)
    if server_running == False:
        f = open(f"{server_directory}/logs/latest.log","r")
        tinput = f.read()
    else:
        tinput = "The server is running please stop so see the log"
    e1 = ttk.Text(master=mainframe,width=60,height=20)
    e1.grid(row=1,column=0)
    e1.insert("1.0",tinput)
    e1["state"] = "disabled"
    mainframe.pack()
    e.close()
    mainframe.pack()

def main_menu():
    global mainframe, start_button, stop_button, run_server_dir, server_directory, server_running
    root.geometry("500x300")
    server = settings['servers'][global_varables["server_index"]]
    mainframe.destroy()
    t = server["name"]
    root.title(f"PyMC-Server - {t}")
    global_varables['runtime_options'] = {"usepopen":True}
    mainframe = ttk.Frame(master=root)

    run_server_dir = settings['servers'][global_varables['server_index']]['directory']

    if server_running == True:
        bstate = "disabled"
    else:
        bstate = "enabled"
    
    if server_running == True:
        sbstate = "enabled"
    else:
        sbstate = "disabled"

    start_button = ttk.Button(master=mainframe,text="Start",bootstyle="success",command=start,state=bstate)
    start_button.grid(row=0,column=1)

    stop_button = ttk.Button(master=mainframe,text="Stop",bootstyle="danger",command=send_stop,state=sbstate)
    stop_button.grid(row=0,column=2)

    l1 = ttk.Label(master=mainframe,text=server['name'],font=("",20))
    l1.grid(row=0,column=0,padx=40)

    b1 = ttk.Button(master=mainframe,text="Server settings",command=openserversettings)
    b1.grid(row=2,column=1,pady=15)
    b2 = ttk.Button(master=mainframe,text="World manager",command=worldmanager)
    b2.grid(row=2,column=0,pady=15)

    b3 = ttk.Button(master=mainframe,text="Plugins manager",command=plugins)
    b3.grid(row=3,column=1,pady=15)
    b4 = ttk.Button(master=mainframe,text="App settings",command=appsettings)
    b4.grid(row=3,column=0,pady=15,padx=3)
    b4 = ttk.Button(master=mainframe,text="Logs",command=serverlogging)
    b4.grid(row=4,column=0,pady=15)
    

    mainframe.pack()

startmenu()

root.protocol("WM_DELETE_WINDOW",on_closing)
ico = Image.open(f'{app_directory}/Assets/icon.ico')
icon = ImageTk.PhotoImage(ico)
root.wm_iconphoto(False,icon)
root.mainloop()