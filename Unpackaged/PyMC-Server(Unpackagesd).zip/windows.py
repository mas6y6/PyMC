import tkinter as tk
import ttkbootstrap as ttk
import threading

def _showabout():
    window = tk.Tk()
    window.title("PyMC-Server - About")
    window.resizable(False,False)
    t = ttk.Text(master=window)
    t.pack()
    t.insert("1.0","""PyMC-Server

This is an application that installs on minecraft server for free for you.
You can manage and make new servers with no ads and no in-app purchases. This is not just a server installer its a manager and maker
this application will install PaperMC server which its SUPER FAST!!!
             
Made and maintained by @mas6y6 on github
""")
    t.config(state='disabled')
    window.mainloop()

def running():
    window = tk.Tk()
    window.title("PyMC-Server - About")
    window.resizable(False,False)
    window.geometry("600x300")
    t = ttk.Text(master=window)
    t.pack()
    t.insert("1.0","""The server is currently active
""")
    t.config(state='disabled')
    window.mainloop()

def showabout():
    threading.Thread(_showabout()).start()